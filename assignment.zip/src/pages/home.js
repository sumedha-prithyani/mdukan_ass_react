import React from 'react';
import Manosupermarket from '../components/Manosupermarket'

const Home = () => {
    return(
        <div>
            <Manosupermarket/>
        </div>
    )
}
export default Home;