import React, { useState } from 'react';
import '../stylesheets/products.css';

import items from "../products.json";

const Products = () => {
    const [itemcounter, setitemcounter] = useState(0);
    let productList = items.products.map((rec, index) => (
        <div className="col-12 col-md-4 col-sm-6 col-xl-3 mb-3 product-block">
            <div className="media">
                <img className="product-img" src={rec.img} alt="Generic placeholder image"/>
                {rec.offer.offer_off && <div className="product-offer-box">{rec.offer.off_ratio}% OFF</div>}
                <div className="media-body">
                    <div className="mt-0 mb-2 product-title">{rec.title}</div>
                    <div className="mt-0 mb-2 product-unit">{rec.unit} Unit</div>
                    <div className="mt-0 mb-2 product-prices">
                    <div class="d-flex">
                        <div class="flex-grow-1">
                            <span className="new_price"><i className="fa fa-inr"></i>{rec.new_price}</span>
                            {rec.old_price && <span className="old_price"><s><i className="fa fa-inr"></i>{rec.old_price}</s></span>}
                        </div>
                        <div>
                            {rec.is_available 
                            ? 
                                <div className="item-action">
                                    {
                                        items.products.length - 1 === index
                                        ? <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                            <label class="btn btn-outline-primary" onClick={(e) => {itemcounter > 0 ? setitemcounter(itemcounter-1) : setitemcounter(itemcounter)}}>
                                                <i className="fa fa-minus"></i>
                                            </label>
                                            <label class="btn">
                                                {itemcounter}
                                            </label>
                                            <label class="btn btn-outline-primary" onClick={(e) => setitemcounter(itemcounter+1)}>
                                                <i className="fa fa-plus"></i>
                                            </label>
                                        </div>
                                        : <div className="product-additem">
                                            <button className="product-additem btn">Add <i className="fa fa-plus"></i></button>
                                        </div>
                                    }
                                </div>
                            : <div className="product-outstock">Out of stock</div>
                            }  
                        </div>
                    </div>                        
                    </div>                    
                </div>
            </div>
        </div>
    ));
    return(
        <div className="productList">            
            <h6 className="my-3">Ice Creams <span class="badge badge-primary">{items.products.length}</span></h6>
            <div className="row media-no-gutters">
                {productList}
            </div>
        </div>
    )
}
export default Products;