import React from 'react';

const Header = () => {
    return(
        <div>
            <div>
                <nav class="navbar text-white" style={{"backgroundColor": "#146eb4"}}>
                    <span>Store made with <i class="fa fa-shopping-bag" aria-hidden="true"> Dukan</i></span> <a style={{"textDecoration": "underline"}} className="text-white" href="#">Download app</a>
                </nav>
            </div>
            <div style={{"borderBottom": "solid 1px #e6e6e6", "padding": "10px"}}>
                <div class="media">
                    <img class="mr-3" style={{'height': '50px'}} src="https://cdn.zeplin.io/5f55fc7188711979abd53600/assets/BFFB50CE-4C7A-4D67-ABA3-DAE760FBDF1D.png" alt="Generic placeholder image"/>
                    <div class="media-body">
                        <h5 class="mt-0 mb-0">Mano Super Market</h5>
                        <span style={{"color":"#17b31b", "fontWeight":"500", "textTransform": "uppercase","fontSize": "12px"}}><i class="fa fa-check-circle" aria-hidden="true"></i> Trusted seller</span>
                    </div>
                </div>
                <div>
                <form class="form-inline mt-2 my-lg-0">
                    <input class="form-control mr-sm-2" style={{"padding": "12px 159px 12px 12px","borderRadius": "6px","backgroundColor": "#f2f2f2","marginTop": "15px", "width":"100%"}} type="search" placeholder="Search" aria-label="Search"/>
                </form>
                </div>
            </div>
        </div>
    )
}
export default Header;