import React from 'react';
import '../stylesheets/bestseller.css';
import Slider from "react-slick";
import items from "../products.json";

const Bestseller = () => {
    var settings = {
        dots: false,
        infinite: true,
        arrows : false,
        infinite: true,
        centerMode: true,
        centerPadding: '5%',      
        slidesToShow: 6,
        slidesToScroll: 1,
        initialSlide: 0,
        responsive: [
          {
            breakpoint: 1024,
            settings: {
              slidesToShow: 4,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 600,
            settings: {
              slidesToShow: 4,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 2,              
              slidesToScroll: 1
            }
          }
        ]
      };
    
    let sliderlists = items.bestseller.map(rec => (
        <div>
            <div className="imgset">
            <img style={{'width':'124px'}} src={rec.img} alt={"image bestseller "+rec.title} class="img-thumbnail p-0 border-0"/>
            <div className="imgoverlay"></div>
            <div className="imgcaption">{rec.title}</div>
            </div>
        </div>
    ))
    
    return(
        <div>            
           <h6 className="my-3">Bestsellers</h6> 
            <div>
            <Slider {...settings}>
                {sliderlists}
            </Slider>
        </div>
        </div>
    )
}
export default Bestseller;