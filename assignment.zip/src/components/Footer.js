import React from 'react';

const Footer = () => {
    return(
        <div className="bg-dark">
            <div className="container-space" style={{"padding":"10px 30px"}}>
                <div class="row">
                    <div className="col text-center">
                        <figure class="figure">
                            <img src="https://cdn.zeplin.io/5f55fc7188711979abd53600/assets/58460ADA-2939-44CC-8B85-432155A5F477.svg" class="figure-img img-fluid rounded" alt="delivery"/>
                            <figcaption class="figure-caption text-white" style={{'fontSize':"12px"}}>Free Delivery (above ₹500)</figcaption>
                        </figure>
                    </div>
                    <div className="col text-center">
                        <figure class="figure">
                            <img src="https://cdn.zeplin.io/5f55fc7188711979abd53600/assets/5E268CA9-897E-45FF-A68D-54BCF71B16B0.svg" class="figure-img img-fluid rounded" alt="delivery"/>
                            <figcaption class="figure-caption text-white" style={{'fontSize':"12px"}}>Buyer Protection</figcaption>
                        </figure>
                    </div>
                    <div className="col text-center">
                        <figure class="figure">
                            <img src="https://cdn.zeplin.io/5f55fc7188711979abd53600/assets/C4B71806-77DD-42A6-801B-FF623BFA125C.svg" class="figure-img img-fluid rounded" alt="delivery"/>
                            <figcaption class="figure-caption text-white" style={{'fontSize':"12px"}}>Customer Support</figcaption>
                        </figure>
                    </div>
                </div>
                <div className="mt-2 text-center text-white" style={{"border-top":"1px solid rgb(88 88 88)"}}>
                   <div>Store Details</div>
                   <div>Mano Super Market</div>
                   <div>Krishvi Terazzo, 80 Feet Road Indiranagar, Bengaluru, Karnataka</div>
                </div>
            </div>
        </div>
    )
}
export default Footer;