import React from 'react';
import Products from './Products';
import Bestseller from './Bestseller';

const Manosupermarket = () => {
    return(
        <div className="container-fluid">
            <div>
                <Bestseller/>
                <Products/>
            </div>
        </div>
    )
}
export default Manosupermarket;